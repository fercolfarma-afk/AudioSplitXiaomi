# Audio Split Xiaomi — prototipo diagnóstico v0.1

Objetivo: Xiaomi 14T / HyperOS 3 / sin root.

## Qué hace
- Enumera salidas de audio conectadas (altavoz, Bluetooth, USB, etc.).
- Permite elegir una salida y reproducir un tono propio de 440 Hz durante 2 segundos.
- Informa si `AudioTrack.setPreferredDevice()` aceptó la preferencia y la ruta observada con `getRoutedDevice()`.
- No pide permisos peligrosos, no captura audio, no controla aplicaciones ajenas.

## Qué NO hace
No separa el audio de Spotify, WhatsApp, YouTube ni de cualquier otra aplicación instalada. Android no ofrece a una app normal una API pública para imponer rutas independientes al audio de otras apps. La capacidad de enrutar audio propio tampoco implica que la reproducción simultánea en altavoz y Bluetooth esté admitida.

## Compilación
1. Abrir esta carpeta con Android Studio (JDK 17 y SDK Android 35 instalados).
2. Permitir sincronización Gradle y descargar dependencias si hace falta.
3. Build > Build APK(s), o ejecutar `gradle assembleDebug` con Gradle compatible y Android SDK configurado.
4. Instalar `app/build/outputs/apk/debug/app-debug.apk` en el Xiaomi 14T con depuración USB habilitada.

El archivo ZIP no incluye un APK ni Gradle Wrapper; no se ha compilado aquí por falta de SDK/Gradle. Android Studio puede importar y sincronizar el proyecto. Si se desea wrapper reproducible, generar con Gradle 8.9: `gradle wrapper --gradle-version 8.9`.

## Protocolo de prueba
1. Desconectar Bluetooth; actualizar; seleccionar altavoz; reproducir tono y anotar salida.
2. Conectar parlante Bluetooth multimedia; actualizar; probar Bluetooth y verificar auditivamente.
3. Manteniendo Bluetooth conectado, seleccionar altavoz interno; reproducir tono; verificar si suena en altavoz o Bluetooth y anotar `Ruta observada`.
4. Abrir Spotify u otra app y reproducir audio; comprobar que la app de diagnóstico no cambia su ruta.
5. Repetir con opción HyperOS `Múltiples fuentes de audio` activada/desactivada.

## Interpretación
- `Preferencia aceptada = true`: solicitud admitida, NO prueba que haya salido por ese dispositivo.
- `Ruta observada`: ruta reportada por Android para nuestro AudioTrack; verificar con escucha real.
- Si ambas rutas de prueba funcionan, solo se demuestra enrutamiento del audio PROPIO, no separación por aplicación.
- Si falla, registrar versión exacta de HyperOS, Android, Bluetooth y resultados.

## Referencias
https://developer.android.com/reference/android/media/AudioTrack
https://developer.android.com/reference/android/media/AudioManager
https://android.googlesource.com/platform/frameworks/base/+/master/core/res/AndroidManifest.xml
