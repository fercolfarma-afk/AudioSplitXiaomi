# Compilar Audio Split Xiaomi desde el celular

1. Entrá a https://github.com/new e iniciá sesión.
2. Nombre del repositorio: `AudioSplitXiaomi`. Elegí **Private** y marcá **Add a README file**. Creá el repositorio.
3. Abrí el repositorio, pulsá **Add file > Upload files** (en Chrome podés activar **Sitio para computadora**).
4. El archivo ZIP no se sube como proyecto: primero descomprimilo con el administrador de archivos. GitHub web puede ser incómodo para subir carpetas y archivos ocultos desde Android. Si no aparecen todas las carpetas, conviene usar la alternativa indicada abajo.
5. Subí los archivos manteniendo exactamente su estructura, incluida `.github/workflows/build-apk.yml`.
6. En el repositorio, abrí **Actions**, elegí **Compilar APK de diagnóstico**, pulsá **Run workflow** y confirmá.
7. Cuando finalice correctamente, entrá a esa ejecución, sección **Artifacts**, y descargá `AudioSplitXiaomi-diagnostico-debug`. Descomprimí el ZIP del artefacto e instalá `app-debug.apk`.
8. Android puede solicitar habilitar instalación desde esa fuente. Solo instalá APK compilados en tu propio repositorio y verificá su procedencia.

## Alternativa para evitar subir carpetas desde el teléfono

En el repositorio, usá **Add file > Create new file** para crear `.github/workflows/build-apk.yml` y los demás archivos, copiando sus contenidos. Es más laborioso pero funciona desde el navegador.

## Alcance real

Esta versión solo prueba sonidos producidos por Audio Split Xiaomi. No permite redirigir el audio de cualquier aplicación externa, ni demuestra compatibilidad universal. La compilación todavía no fue comprobada en un Xiaomi 14T real.
