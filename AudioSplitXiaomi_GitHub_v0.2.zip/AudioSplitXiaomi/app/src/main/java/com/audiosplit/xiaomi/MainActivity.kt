package com.audiosplit.xiaomi

import android.app.Activity
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : Activity() {
    private lateinit var manager: AudioManager
    private lateinit var output: TextView
    private lateinit var picker: Spinner
    private var devices: List<AudioDeviceInfo> = emptyList()
    private val worker = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        manager = getSystemService(AUDIO_SERVICE) as AudioManager
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,28,28,28) }
        val heading = TextView(this).apply { text = "Audio Split Xiaomi · Diagnóstico v0.1"; textSize = 21f }
        layout.addView(heading)
        layout.addView(TextView(this).apply { text = "Prueba SOLO audio generado por esta aplicación. No redirige Spotify, WhatsApp ni otras apps. Conectá Bluetooth antes de probar." })
        picker = Spinner(this); layout.addView(picker)
        val refresh = Button(this).apply { text = "Actualizar salidas" }; layout.addView(refresh)
        val test = Button(this).apply { text = "Reproducir tono de prueba (2 s)" }; layout.addView(test)
        output = TextView(this).apply { textSize = 14f }; layout.addView(output)
        setContentView(ScrollView(this).apply { addView(layout) })
        refresh.setOnClickListener { refreshDevices() }
        test.setOnClickListener { if (devices.isNotEmpty()) testDevice(devices[picker.selectedItemPosition]) }
        refreshDevices()
    }
    private fun deviceName(d: AudioDeviceInfo): String = when(d.type) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Altavoz interno"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth A2DP"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth SCO (llamadas)"
        AudioDeviceInfo.TYPE_BLE_HEADSET -> "Bluetooth LE auricular"
        AudioDeviceInfo.TYPE_BLE_SPEAKER -> "Bluetooth LE parlante"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "Auricular USB"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES -> "Auriculares cableados"
        else -> "Tipo ${d.type}"
    } + " · id ${d.id}"
    private fun refreshDevices() {
        devices = manager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).filter { it.isSink }.toList()
        picker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, devices.map(::deviceName))
        output.text = "Modelo: ${Build.MANUFACTURER} ${Build.MODEL}\nAndroid API: ${Build.VERSION.SDK_INT}\nSalidas: ${devices.size}\n\nLimitación: Android no permite a esta app imponer una ruta por aplicación externa."
    }
    private fun testDevice(device: AudioDeviceInfo) {
        output.append("\nProbando ${deviceName(device)}...")
        worker.execute {
            val rate = 44100
            val samples = rate * 2
            val buffer = ShortArray(samples) { i -> (sin(2 * PI * 440.0 * i / rate) * 0.18 * Short.MAX_VALUE).toInt().toShort() }
            var track: AudioTrack? = null
            try {
                track = AudioTrack.Builder()
                    .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                    .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                    .setTransferMode(AudioTrack.MODE_STATIC).setBufferSizeInBytes(buffer.size * 2).build()
                val accepted = track.setPreferredDevice(device)
                track.write(buffer, 0, buffer.size)
                track.play()
                Thread.sleep(500)
                val actual = track.routedDevice?.let(::deviceName) ?: "No informado"
                Thread.sleep(1700)
                main.post { output.append("\nPreferencia aceptada: $accepted\nRuta observada: $actual\nConfirmá auditivamente la salida; aceptar preferencia NO garantiza ruta física.\n") }
            } catch(e: Exception) { main.post { output.append("\nError: ${e.message}\n") } }
            finally { try { track?.stop() } catch (_: Exception) {}; track?.release() }
        }
    }
    override fun onDestroy() { worker.shutdown(); super.onDestroy() }
}
